"""Browser smoke tests. Setup: pip install -r requirements-dev.txt ; playwright install chromium
Run: pytest tests/e2e -v   (skipped automatically if Playwright is not installed)"""
import os, subprocess, sys, tempfile, time, urllib.request, pathlib
import pytest
pytest.importorskip("playwright")
from playwright.sync_api import sync_playwright

PORT, BASE = 5099, "http://127.0.0.1:5099"
OUT = pathlib.Path(__file__).parent / "screenshots"
SIZES = {"desktop": (1440, 900), "laptop": (1280, 800), "tablet": (768, 1024), "mobile": (390, 844), "narrow": (320, 700)}

@pytest.fixture(scope="module")
def server():
    d = tempfile.mkdtemp()
    env = dict(os.environ, DATABASE_URL="sqlite:///" + os.path.join(d, "e2e.db").replace("\\", "/"), AI_API_KEY="", SECRET_KEY="e2e")
    p = subprocess.Popen([sys.executable, "-m", "flask", "--app", "run", "run", "--port", str(PORT)], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(40):
        try: urllib.request.urlopen(BASE); break
        except Exception: time.sleep(0.5)
    yield
    p.terminate()

def test_flow_overflow_console_and_screenshots(server):
    OUT.mkdir(exist_ok=True)
    with sync_playwright() as pw:
        b = pw.chromium.launch(); pg = b.new_page(viewport={"width": 1440, "height": 900})
        errors = []
        pg.on("console", lambda m: errors.append(m.text) if m.type == "error" else None); pg.on("pageerror", lambda e: errors.append(str(e)))
        pg.goto(BASE + "/dashboard"); assert "/login" in pg.url                      # protected page redirects
        pg.goto(BASE + "/register"); pg.get_by_label("Name").fill("E2E"); pg.get_by_label("Email").fill("e2e@example.com"); pg.get_by_label("Password").fill("password123")
        pg.get_by_role("button", name="Create account").click()
        pg.get_by_label("Email").fill("e2e@example.com"); pg.get_by_label("Password").fill("password123"); pg.get_by_role("button", name="Sign in").click()
        pg.wait_for_url("**/dashboard"); assert pg.get_by_role("heading", name="Welcome back", exact=False).is_visible()
        pg.get_by_role("button", name="Open IQ Coach chat").click(); pg.get_by_label("Message to IQ Coach").fill("Create a 7-day study plan")
        pg.get_by_role("button", name="Send").click(); pg.get_by_text("Demo coach (rule-based)").first.wait_for()
        for name, (w, h) in SIZES.items():
            pg.set_viewport_size({"width": w, "height": h}); pg.goto(BASE + "/dashboard")
            pg.add_style_tag(content="*{animation:none!important;transition:none!important}")
            assert pg.evaluate("document.documentElement.scrollWidth <= window.innerWidth + 1"), f"horizontal overflow at {name}"
            pg.screenshot(path=str(OUT / f"dashboard-{name}.png"))
        assert not errors, errors
        b.close()
