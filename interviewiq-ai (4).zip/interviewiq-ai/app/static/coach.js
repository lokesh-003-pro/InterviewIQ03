(()=>{const $=i=>document.getElementById(i),box=$('cq');if(!box)return;
const log=$('cq-log'),inp=$('cq-in'),tok=document.querySelector('meta[name=csrf-token]').content,fab=$('cq-open');let loaded=false;
const hm=()=>new Date().toTimeString().slice(0,5);
function btn(t,f){const b=document.createElement('button');b.type='button';b.className='btn alt';b.textContent=t;b.onclick=f;return b}
function add(role,text,label,time,acts){const d=document.createElement('div');d.className='cq-m '+role;const p=document.createElement('p');p.textContent=text;d.append(p);
const f=document.createElement('div');f.className='cq-f';f.textContent=(label?label+' - ':'')+(time||'');d.append(f);
if(role==='assistant'){d.append(btn('Copy',()=>navigator.clipboard&&navigator.clipboard.writeText(text)));
if('speechSynthesis' in window)d.append(btn('Listen',()=>{speechSynthesis.cancel();speechSynthesis.speak(new SpeechSynthesisUtterance(text))}));
(acts||[]).forEach(a=>{const l=document.createElement('a');l.className='btn';l.href=a.url;l.textContent=a.label;d.append(l)})}
log.append(d);log.scrollTop=log.scrollHeight;return d}
async function send(text,retryEl){if(retryEl)retryEl.remove();else add('user',text,'',hm());
const w=add('assistant','Thinking...','','');
try{const r=await fetch('/coach/message',{method:'POST',headers:{'Content-Type':'application/json','X-CSRFToken':tok},body:JSON.stringify({message:text})});
const j=await r.json();w.remove();if(!r.ok)throw new Error(j.error||'Something went wrong.');add('assistant',j.reply,j.label,hm(),j.actions)}
catch(e){w.remove();const m=add('error',e.message||'Could not reach the server.','','');m.append(btn('Retry',()=>send(text,m)))}}
async function load(){if(loaded)return;loaded=true;try{const j=await (await fetch('/coach/history')).json();j.messages.forEach(m=>add(m.role,m.content,m.label,m.time))}catch(e){}}
$('cq-form').onsubmit=e=>{e.preventDefault();const t=inp.value.trim();if(!t)return;inp.value='';send(t)};
inp.onkeydown=e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();$('cq-form').requestSubmit()}};
document.querySelectorAll('.cq-chip').forEach(c=>c.onclick=()=>send(c.textContent));
$('cq-clear').onclick=async()=>{if(!confirm('Clear this conversation?'))return;await fetch('/coach/clear',{method:'POST',headers:{'X-CSRFToken':tok}});log.replaceChildren()};
if(fab){const open=o=>{box.hidden=!o;fab.setAttribute('aria-expanded',o);if(o){load();inp.focus()}else fab.focus()};fab.onclick=()=>open(box.hidden);$('cq-close').onclick=()=>open(false);box.onkeydown=e=>{if(e.key==='Escape')open(false)}}else load()})();