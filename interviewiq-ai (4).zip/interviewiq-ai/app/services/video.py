"""Builds feedback for a spoken video-interview answer from MEASURABLE signals only.
Pronunciation is not scored: low speech-recogniser confidence can come from noise, microphone or accent."""
from . import ai, english as en
from .evaluator import evaluate

def build(question, text, kw, dur, segs, pauses, first_ms, vis):
    ev = ai.evaluate_answer(question, text) or evaluate("hr", text, kw)
    r = en.check(text)
    words = len(text.split())
    fillers = ev.get("fillers", r["eval"]["fillers"]); ev["fillers"] = fillers; ev.setdefault("words", words)
    wpm = round(words / (dur / 60)) if dur >= 10 else None
    longest = round(max(pauses) / 1000, 1) if pauses else 0
    delay = round(first_ms / 1000, 1) if first_ms is not None else None
    low = [s["text"] for s in segs if 0 < s["conf"] < 0.75][:4]
    I = []
    add = lambda w, f: I.append({"wrong": w, "fix": f})
    if wpm and wpm < 100: add(f"You spoke slowly ({wpm} words per minute).", "Aim for about 110-160 words per minute. Practise the answer aloud once before recording.")
    if wpm and wpm > 170: add(f"You spoke fast ({wpm} words per minute).", "Slow down and breathe between sentences so the interviewer can follow.")
    if fillers >= 3: add(f"You used {fillers} filler words (um, uh, like, basically, actually).", "Pause silently for a second instead of filling the gap.")
    if len(pauses) >= 3 or longest >= 4: add(f"You paused {len(pauses)} time(s) for 2 seconds or more (longest {longest} s).", "Plan 3 key points before you start. If you need time, say 'Let me think for a moment.'")
    if delay is not None and delay > 6: add(f"You took {delay} seconds to begin speaking.", "Start with a short opening sentence that restates the question.")
    if words < 40: add(f"Your answer was short ({words} words).", "Add one real example with a result. Aim for 60-150 words.")
    if words > 250: add(f"Your answer was long ({words} words).", "Keep it under about 2 minutes: main point, one example, result.")
    if low: add("The browser could not recognise these parts clearly: " + " | ".join('"' + t[:60] + '"' for t in low), "Speak a little slower and clearer, check your microphone and background noise. This can also be caused by accent or the browser, so it is not proof of a mistake.")
    if r["corrections"]: add(f"{len(r['corrections'])} sentence(s) have common grammar or wording mistakes.", "See the corrections list below and say the corrected sentence aloud.")
    for m in ev.get("improvements", [])[:3]: add("Content: " + m, "Revise your answer using this point.")
    if vis:
        if vis["lit"] < 70: add(f"Lighting was low in {100 - vis['lit']}% of checks.", "Face a window or lamp so the light is in front of you, not behind.")
        if vis["face"] is not None and vis["face"] < 80: add(f"Your face was out of the camera view in {100 - vis['face']}% of checks.", "Raise the camera to eye level and stay inside the frame.")
        if vis["centred"] is not None and vis["centred"] < 60: add("You were often off-centre.", "Sit in the middle of the frame.")
    if not I: add("No common problems were found by these checks.", "Try a harder question, or record a second take and compare.")
    speech = {"seconds": int(dur), "wpm": wpm, "fillers": fillers, "pauses": len(pauses), "longest": longest, "start_delay": delay}
    return {"ev": ev, "issues": I, "corrections": r["corrections"], "improved": r["improved"], "speech": speech, "lowconf": low}
