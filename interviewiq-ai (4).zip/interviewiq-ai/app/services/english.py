"""Rule-based English check. It finds a fixed set of common mistakes. It is NOT a full grammar
checker, and it never scores accent or pronunciation."""
import re
RULES = [(r"\bi am agree\b", "I agree", "'agree' is a verb, so 'am' is not needed."),
 (r"\bmore better\b", "better", "'better' is already a comparative form."),
 (r"\bmy self\b", "myself", "Write 'myself' as one word."),
 (r"\bI am having (\d+|a|an) ", r"I have \1 ", "Use 'have' for possession."),
 (r"\bI am knowing\b", "I know", "'know' is not used in continuous form."),
 (r"\bdiscuss about\b", "discuss", "'discuss' does not need 'about'."),
 (r"\bemphasize on\b", "emphasize", "'emphasize' does not need 'on'."),
 (r"\bI have completed my graduation\b", "I have graduated", "'graduated' sounds more natural."),
 (r"\bI am from last (year|month)\b", r"I have been here since last \1", "Rephrase to show time clearly."),
 (r"\bone of the (\w+) (\w+)s? (is|was)\b", None, None)]
VOCAB = {"good": "strong, effective", "bad": "poor, weak", "very good": "excellent", "thing": "aspect, point", "get": "obtain, receive", "nice": "pleasant, impressive", "lots of": "many, a number of"}
FILL = ["um", "uh", "like", "basically", "actually"]

def check(text, seconds=0):
    sents = [s.strip() for s in re.split(r"(?<=[.!?])\s+", text.strip()) if s.strip()]
    fixes, out = [], []
    for s in sents:
        t, notes = s, []
        for pat, rep, why in RULES:
            if rep is None: continue
            n = re.sub(pat, rep, t, flags=re.I)
            if n != t: t = n; notes.append(why)
        n = re.sub(r"\bi\b", "I", t)
        if n != t: t = n; notes.append("Write the pronoun 'I' with a capital letter.")
        m = re.search(r"\b(\w+) \1\b", t, flags=re.I)
        if m and m.group(1).lower() not in ("that", "had"):
            t = re.sub(r"\b(\w+) \1\b", r"\1", t, flags=re.I); notes.append("A word was repeated.")
        if t and t[0].islower(): t = t[0].upper() + t[1:]; notes.append("Start a sentence with a capital letter.")
        if len(t.split()) > 35: notes.append("This sentence is long. Try splitting it in two.")
        out.append(t)
        if t != s or notes: fixes.append({"original": s, "better": t, "why": " ".join(notes) or "Check the wording."})
    low = text.lower(); words = re.findall(r"[a-z']+", low)
    vocab = [f"Instead of '{k}' you could say: {v}" for k, v in VOCAB.items() if re.search(r"\b" + k + r"\b", low)][:4]
    fill = sum(words.count(f) for f in FILL)
    score = max(40, 100 - 10 * len(fixes) - min(fill * 2, 10))
    good = ["You wrote %d words in %d sentence(s)." % (len(words), len(sents))] + (["No common mistakes from our checklist were found."] if not fixes else [])
    better = [f"{len(fixes)} sentence(s) can be improved. See the corrections below."] if fixes else []
    if fill > 2: better.append(f"{fill} filler words found. A short pause works instead.")
    if len(words) < 25: better.append("Add more detail: aim for at least 40 words.")
    return {"corrections": fixes, "improved": " ".join(out), "vocab": vocab,
            "eval": {"score": score, "words": len(words), "fillers": fill, "strengths": good, "improvements": better + vocab,
                     "label": "Demo rule-based check of common mistakes only. It does not judge accent, pronunciation or fluency."}}
