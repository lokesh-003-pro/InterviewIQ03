"""Optional AI provider (Anthropic Messages API). Falls back to demo logic on any problem."""
import os, json, urllib.request

def configured():
    return bool(os.getenv("AI_API_KEY"))

def _call(prompt):
    body = json.dumps({"model": os.getenv("AI_MODEL", "claude-sonnet-4-6"), "max_tokens": 1000,
                       "messages": [{"role": "user", "content": prompt}]}).encode()
    req = urllib.request.Request("https://api.anthropic.com/v1/messages", body, {
        "content-type": "application/json", "x-api-key": os.environ["AI_API_KEY"], "anthropic-version": "2023-06-01"})
    with urllib.request.urlopen(req, timeout=20) as r:
        t = json.load(r)["content"][0]["text"]
    return json.loads(t[t.find("{"):t.rfind("}") + 1])

def make_questions(matched, missing):
    if configured():
        try:
            d = _call('Write 8 interview questions for a candidate. Skills on their resume: %s. Skills the job wants that are missing: %s. '
                      'Reply with JSON only: {"questions": ["..."]}' % (", ".join(matched) or "none", ", ".join(missing) or "none"))
            qs = [str(x) for x in d["questions"]][:8]
            if qs: return qs, "AI-generated"
        except Exception:
            pass
    qs = ["Walk me through your resume."]
    qs += [f"Describe a project where you used {s}. What was your role and what did you learn?" for s in matched[:5]]
    qs += [f"The role mentions {s}. How would you get up to speed on it?" for s in missing[:3]]
    return qs, "Demo (rule-based)"

def evaluate_answer(question, answer):
    """Returns the same shape as the demo evaluator, or None if AI is off or fails."""
    if not configured():
        return None
    try:
        d = _call('Score this interview answer 0-100 for relevance, structure, completeness and clarity. Question: %s\nAnswer: %s\n'
                  'Reply with JSON only: {"score": int, "strengths": [str], "improvements": [str]}' % (question, answer[:3000]))
        return {"score": max(0, min(100, int(d["score"]))), "strengths": [str(x) for x in d["strengths"]][:5],
                "improvements": [str(x) for x in d["improvements"]][:5],
                "label": "AI-generated feedback. It is an opinion, not objective truth, and can be wrong."}
    except Exception:
        return None

def new_question(module, asked, last="", domain=""):
    """Ask the AI for a fresh question that does not repeat earlier ones. Returns (text, label) or (None, None)."""
    if not configured():
        return None, None
    names = {"hr": "HR", "gd": "group discussion topic", "tech": "technical"}
    try:
        d = _call("Write ONE new %s interview question for a %s candidate. Do not repeat or closely resemble any of these: %s. %s"
                  'Reply with JSON only: {"question": "..."}' % (names.get(module, "interview"), (domain or "general graduate")[:60], json.dumps(asked[-8:]),
                  ("The candidate's previous answer was: %s. Make it a natural follow-up if that fits. " % last[:200]) if last else ""))
        q = str(d["question"]).strip()
        return (q, "AI-generated question") if 10 < len(q) < 300 else (None, None)
    except Exception:
        return None, None

def chat(system, msgs):
    """Plain-text chat call. Raises on any failure so the caller can fall back to the demo coach."""
    body = json.dumps({"model": os.getenv("AI_MODEL", "claude-sonnet-4-6"), "max_tokens": 700, "system": system, "messages": msgs}).encode()
    req = urllib.request.Request("https://api.anthropic.com/v1/messages", body, {
        "content-type": "application/json", "x-api-key": os.environ["AI_API_KEY"], "anthropic-version": "2023-06-01"})
    with urllib.request.urlopen(req, timeout=25) as r:
        return json.load(r)["content"][0]["text"].strip()
