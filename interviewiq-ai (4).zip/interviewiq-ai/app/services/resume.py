import re
from pypdf import PdfReader
SKILLS = ["python","java","c++","c#","javascript","typescript","html","css","react","node","flask","django","sql","mysql","postgresql","mongodb",
          "git","docker","aws","linux","machine learning","deep learning","pandas","numpy","tensorflow","excel","power bi","tableau",
          "communication","leadership","teamwork","problem solving","networking","oop","data structures","algorithms","electrical","plumbing"]

def extract_text(stream):
    try:
        text = "\n".join((p.extract_text() or "") for p in PdfReader(stream).pages)
    except Exception:
        return None, "That file could not be read as a PDF."
    if len(text.strip()) < 50:
        return None, "No readable text found. Scanned PDFs are not supported, so export a text-based PDF."
    return text.strip(), None

def find_skills(text):
    low = text.lower()
    return [s for s in SKILLS if re.search(r"(?<![a-z+#])" + re.escape(s) + r"(?![a-z+#])", low)]

def analyze(text, jd):
    have, want = find_skills(text), find_skills(jd or "")
    return {"skills": have, "matched": [s for s in want if s in have], "missing": [s for s in want if s not in have]}
