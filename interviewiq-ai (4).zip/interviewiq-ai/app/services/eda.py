"""EDA helpers. Pure functions so they are easy to test. Uses only the standard library.
Scores are percentages (0-100). Missing or out-of-range scores are excluded, never treated as zero."""
import statistics as st
THRESH = 2.0  # percentage points: a change smaller than this counts as 'Unchanged'

def valid(rows):
    good = [a for a in rows if isinstance(a.score, (int, float)) and 0 <= a.score <= 100]
    return good, len(rows) - len(good)

def describe(scores):
    n = len(scores)
    if n == 0:
        return None
    return {"n": n, "mean": round(st.mean(scores), 1), "median": round(st.median(scores), 1), "min": round(min(scores), 1), "max": round(max(scores), 1),
            "range": round(max(scores) - min(scores), 1), "std": round(st.stdev(scores), 1) if n > 1 else None}

def rel_change(base, later):
    """Relative % change. Undefined (None) when the baseline is missing or zero."""
    return None if base in (None, 0) else round((later - base) / base * 100, 1)

def label(pp):
    return "Improved" if pp >= THRESH else "Declined" if pp <= -THRESH else "Unchanged"

def compare(A, B):
    sa, sb = [a.score for a in A], [a.score for a in B]
    if not sa or not sb:
        return {"ok": False, "na": len(sa), "nb": len(sb)}
    ma, mb = round(st.mean(sa), 1), round(st.mean(sb), 1)
    pp = round(mb - ma, 1)
    warn = []
    if min(len(sa), len(sb)) < 3: warn.append("One period has fewer than 3 sessions, so this change may be due to chance.")
    if max(len(sa), len(sb)) > 3 * min(len(sa), len(sb)): warn.append("The two periods have very different numbers of sessions.")
    if ma == 0: warn.append("The baseline is 0, so a relative change cannot be calculated.")
    warn.append("No significance test was run, so this does not prove real improvement.")
    return {"ok": True, "na": len(sa), "nb": len(sb), "ma": ma, "mb": mb, "pp": pp, "rel": rel_change(ma, mb), "label": label(pp), "warn": warn}

def _by_topic(rows, names):
    d = {}
    for a in rows: d.setdefault((names.get(a.module, a.module), a.category or "General"), []).append(a.score)
    return d

def topic_compare(A, B, names):
    da, db_ = _by_topic(A, names), _by_topic(B, names)
    out = []
    for k in sorted(set(da) & set(db_)):
        ma, mb = round(st.mean(da[k]), 1), round(st.mean(db_[k]), 1)
        out.append({"module": k[0], "topic": k[1], "na": len(da[k]), "nb": len(db_[k]), "ma": ma, "mb": mb, "pp": round(mb - ma, 1), "label": label(mb - ma)})
    return out

def summary(rows, names):
    scores = [a.score for a in rows]
    bym = {}
    for a in rows: bym.setdefault(names.get(a.module, a.module), []).append(a.score)
    by_module = [(k, len(v), round(st.mean(v), 1)) for k, v in bym.items()]
    hist = [0] * 10
    for s in scores: hist[min(int(s // 10), 9)] += 1
    apt = [a for a in rows if a.module == "aptitude" and a.detail and "items" in a.detail][-10:]
    split = {"labels": [a.created.strftime("%d %b") for a in apt], "correct": [], "incorrect": [], "unanswered": []}
    for a in apt:
        its = a.detail["items"]
        split["correct"].append(sum(1 for i in its if i["ok"])); split["unanswered"].append(sum(1 for i in its if i["picked"] is None))
        split["incorrect"].append(sum(1 for i in its if i["picked"] is not None and not i["ok"]))
    topics = sorted(((m, c, len(v), round(st.mean(v), 1)) for (m, c), v in _by_topic(rows, names).items()), key=lambda t: t[3])
    tips = []
    if len(rows) < 3:
        tips.append(f"Only {len(rows)} session(s) match these filters. There is not enough data for reliable conclusions.")
    good = sorted([m for m in by_module if m[1] >= 2], key=lambda m: m[2])
    if len(good) >= 2 and good[-1][2] != good[0][2]:
        tips.append(f"Your average {good[-1][0]} score ({good[-1][2]}%) is higher than your {good[0][0]} score ({good[0][2]}%) in this period.")
    if len(rows) >= 2:
        f, l = rows[0].score, rows[-1].score
        tips.append(f"Your latest score ({round(l)}%) is {'higher than' if l > f else 'lower than' if l < f else 'the same as'} your first recorded score ({round(f)}%) in this period.")
    sampled = [t for t in topics if t[2] >= 2]
    if sampled: tips.append(f"Suggested next practice: {sampled[0][0]} - {sampled[0][1]} (average {sampled[0][3]}% over {sampled[0][2]} attempts).")
    if any(t[2] == 1 for t in topics): tips.append("Some topics have only one attempt, so compare them cautiously.")
    return {"n": len(rows), "stats": describe(scores), "by_module": by_module, "hist": hist, "split": split, "topics": topics, "tips": tips,
            "trend": {"labels": [a.created.strftime("%d %b") for a in rows], "scores": [round(s, 1) for s in scores]}}
