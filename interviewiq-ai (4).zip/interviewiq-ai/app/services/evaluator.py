"""Demo (rule-based) evaluator for open-ended answers.
Checks measurable signals only: length, structure words, topic keywords, fillers.
It is NOT an AI judgement and cannot verify that an answer is correct."""
import re
FILLERS = ["um", "uh", "basically", "actually", "like"]
STRUCTURE = ["first", "second", "finally", "however", "because", "for example", "as a result", "in conclusion", "therefore"]
STAR = {"situation": ["when", "once", "during"], "task": ["task", "goal", "responsible"],
        "action": ["i decided", "i created", "i led", "i built", "i started", "i worked", "i asked"],
        "result": ["result", "achieved", "improved", "learned", "outcome"]}

def evaluate(module, text, keywords=""):
    low = text.lower()
    words = re.findall(r"[a-z']+", low)
    n = len(words)
    fill = sum(words.count(f) for f in FILLERS)
    struct = [s for s in STRUCTURE if s in low]
    kws = [k.strip().lower() for k in (keywords or "").split(",") if k.strip()]
    hit = [k for k in kws if k in low]
    miss = [k for k in kws if k not in low]
    star = [k for k, v in STAR.items() if any(p in low for p in v)]
    score = (min(n / 100, 1) * 30 + min(len(struct), 4) / 4 * 25
             + ((len(hit) / len(kws) * 35) if kws else 20)
             + (len(star) / 4 * 10 if module == "hr" else 10) - min(fill * 2, 10))
    score = max(0, min(100, round(score)))
    good, better = [], []
    (good if n >= 60 else better).append(f"Length: {n} words. Aim for 60-150 words.")
    (good if len(struct) >= 2 else better).append("Structure words: " + (", ".join(struct) or "none") + ". Try first / because / for example / in conclusion.")
    if hit: good.append("Covered concepts: " + ", ".join(hit))
    if miss: better.append("Concepts not mentioned: " + ", ".join(miss))
    if module == "hr":
        better.append("STAR parts detected: " + (", ".join(star) or "none") + ". Cover Situation, Task, Action, Result using a true example from your own life.")
    if fill > 2: better.append(f"{fill} filler words found. Pause instead.")
    return {"score": score, "words": n, "fillers": fill, "strengths": good, "improvements": better,
            "label": "Demo rule-based score: measures length, structure and keywords only, not true quality."}
