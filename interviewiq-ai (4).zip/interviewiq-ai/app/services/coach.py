"""IQ Coach: AI chat when a key is set, otherwise a clearly labelled rule-based demo coach."""
from . import ai
SYSTEM = ("You are IQ Coach, a friendly interview and career coach inside InterviewIQ AI. Give practical, concise advice. "
          "Encourage truthful answers, never invent personal experiences for the user, and say when you are unsure. "
          "You cannot take actions in the app; suggest pages instead.")
P = lambda m: ("Practise", "main.practice", {"module": m})
RULES = [
 (("python",), "For a Python interview, revise: data types and mutability, list/dict comprehensions, OOP (classes, inheritance), exceptions, decorators and generators, and basic data structures. Practise explaining each in 3-4 sentences with a small example.", [("Technical practice", "main.practice", {"module": "tech"})]),
 (("sql", "dbms", "database"), "For SQL and DBMS, be ready on joins, GROUP BY vs WHERE vs HAVING, indexes, normalisation, transactions and the ACID properties. Explain each with a tiny table example.", [("Technical practice", "main.practice", {"module": "tech"})]),
 (("oop", "polymorphism", "inheritance"), "OOP pillars: encapsulation, abstraction, inheritance and polymorphism. Give one real example for each, such as method overriding for polymorphism.", [("Technical practice", "main.practice", {"module": "tech"})]),
 (("introduc", "about yourself"), "A strong self-introduction has 4 parts: who you are (education), your key skills, one project or experience that proves them, and what you want next. Keep it to about 60-90 seconds and use only true details. Try it out and I can point out gaps.", [("Practise HR", "main.practice", {"module": "hr"})]),
 (("star", "behavio", "teamwork", "conflict"), "Use STAR: Situation (context), Task (your responsibility), Action (what YOU did), Result (the outcome and what you learned). Pick a real example and spend most of your time on Action and Result.", [("Practise HR", "main.practice", {"module": "hr"})]),
 (("resume", "cv"), "Upload your resume on the Resume page to see the skills found, match them against a job description and get practice questions. Matching is keyword-based and is not a hiring decision.", [("Resume & Jobs", "main.resume", {})]),
 (("english", "grammar", "speaking"), "For English practice, speak or type short answers and check them in the English Coach. You get the original sentence, a corrected one and a reason. Aim for short, clear sentences first.", [("English Coach", "main.english", {})]),
 (("study plan", "7-day", "7 day"), "A simple 7-day plan: Day 1 aptitude basics, Day 2 your main technical skill, Day 3 SQL/DBMS, Day 4 HR answers using STAR, Day 5 a mock interview, Day 6 review mistakes, Day 7 rest and light revision. Use your Insights page to choose which topics get more time.", [("EDA & Insights", "main.insights", {})]),
]

def demo(msg, ctx):
    low = msg.lower()
    if any(k in low for k in ("mistake", "last interview", "weak", "improve my", "next practice", "what should i practi")):
        parts = []
        if ctx["improve"]: parts.append("From your latest session, focus on: " + "; ".join(ctx["improve"][:3]))
        if ctx["weak"]: parts.append("Your lowest-scoring topic is %s - %s (average %s%%)." % ctx["weak"][0][:3])
        return ("\n".join(parts) if parts else "You have no saved sessions yet. Complete one practice session and I can point out specific areas."), [("Progress", "main.progress", {})]
    for keys, text, acts in RULES:
        if any(k in low for k in keys):
            return text, acts
    return ("I'm the demo coach, so I answer a fixed set of topics: Python, SQL/DBMS, OOP, self-introduction, STAR answers, resume, English practice, study plans and your weak topics. Try one of the suggestions below. Add an AI key to get open-ended answers."), []

def respond(msg, hist, ctx):
    """Returns (reply, label, actions)."""
    if ai.configured():
        try:
            system = SYSTEM + (" The user's weakest practice topic is %s - %s." % ctx["weak"][0][:2] if ctx["weak"] else "")
            msgs = [{"role": m["role"], "content": m["content"]} for m in hist] + [{"role": "user", "content": msg}]
            while msgs and msgs[0]["role"] != "user": msgs.pop(0)
            return ai.chat(system, msgs), "AI-generated", []
        except Exception:
            text, acts = demo(msg, ctx)
            return "The AI service is not responding right now, so this is a demo-coach answer.\n\n" + text, "Demo coach (rule-based)", acts
    text, acts = demo(msg, ctx)
    return text, "Demo coach (rule-based)", acts
